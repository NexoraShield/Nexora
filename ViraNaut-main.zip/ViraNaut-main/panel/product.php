<?php
require_once __DIR__ . '/inc/config.php';
require_once __DIR__ . '/inc/icons.php';
require_once __DIR__ . '/inc/panel_type_defs.php';
require_once __DIR__ . '/inc/bot_emojis.php';
require_once __DIR__ . '/inc/product_panel_ops.php';
require_auth();

vira_ensure_product_panel_schema($pdo);

if (!function_exists('vira_panel_product_label')) {
    function vira_panel_product_label(string $raw): string
    {
        if (!function_exists('vira_resolve_keyboard_button')) {
            return $raw;
        }
        $resolved = vira_resolve_keyboard_button($raw);
        $text = $resolved['text'] !== '' ? $resolved['text'] : $raw;
        return !empty($resolved['icon_custom_emoji_id']) ? '◆ ' . $text : $text;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'bulk_price') {
  csrf_check_post();
  $ids = array_filter(array_map('intval', (array) ($_POST['product_ids'] ?? [])));
  $mode = ($_POST['bulk_mode'] ?? '') === 'decrease' ? 'decrease' : 'increase';
  $type = ($_POST['bulk_type'] ?? '') === 'percent' ? 'percent' : 'fixed';
  $amount = (int) ($_POST['bulk_amount'] ?? 0);
  if ($ids === [] || $amount <= 0) {
    flash('error', 'حداقل یک محصول و مقدار معتبر انتخاب کنید.');
    header('Location: product.php');
    exit;
  }
  $placeholders = implode(',', array_fill(0, count($ids), '?'));
  $rows = db_fetchAll($pdo, "SELECT id, price_product FROM product WHERE id IN ($placeholders)", $ids);
  $updated = 0;
  foreach ($rows as $row) {
    $price = (int) ($row['price_product'] ?? 0);
    if ($mode === 'increase') {
      if ($type === 'percent') {
        $price = $price + (int) round($price * $amount / 100);
      } else {
        $price = $price + $amount;
      }
    } else {
      $price = max(0, $price - ($type === 'percent' ? (int) round($price * $amount / 100) : $amount));
    }
    db_query($pdo, 'UPDATE product SET price_product = ? WHERE id = ?', [$price, (int) $row['id']]);
    $updated++;
  }
  flash('success', 'قیمت ' . $updated . ' محصول به‌روز شد.');
  header('Location: product.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add') {
  csrf_check_post();
  $name = function_exists('vira_sanitize_button_emoji_label')
    ? vira_sanitize_button_emoji_label(trim($_POST['name_product'] ?? ''))
    : trim($_POST['name_product'] ?? '');
  if ($name === '') {
    flash('error', 'نام محصول الزامی است.');
    header('Location: product.php');
    exit;
  }
  $category = trim((string) ($_POST['cetegory_product'] ?? ''));
  if (vira_product_name_taken($pdo, $name, $category)) {
    $catHint = $category !== '' ? ' در دسته «' . $category . '»' : ' بدون دسته';
    flash('error', 'محصولی با این نام' . $catHint . ' قبلاً ثبت شده. در دستهٔ دیگر می‌توانید همین نام را استفاده کنید.');
    header('Location: product.php');
    exit;
  }
  $code = bin2hex(random_bytes(2));
  $inboundsRaw = trim((string) ($_POST['inbounds_product'] ?? ''));
  $panelName = trim((string) ($_POST['namepanel'] ?? ''));
  if ($panelName !== '') {
    $panelRow = db_fetch($pdo, 'SELECT type FROM marzban_panel WHERE name_panel = ?', [$panelName]);
    if ($panelRow && panel_web_is_xui_type((string) ($panelRow['type'] ?? '')) && ($inboundsRaw === '' || $inboundsRaw === '-')) {
      flash('error', 'برای پنل ۳x-ui انتخاب اینباند الزامی است.');
      header('Location: product.php');
      exit;
    }
  }
  $inboundsVal = ($inboundsRaw === '' || $inboundsRaw === '-') ? null : $inboundsRaw;
  $btnStyle = vira_sanitize_btn_style($_POST['btn_style'] ?? '');
  try {
    db_query(
      $pdo,
      "INSERT INTO product (name_product,code_product,price_product,Volume_constraint,Service_time,Location,agent,data_limit_reset,note,category,inbounds,hide_panel,one_buy_status,btn_style) VALUES (?,?,?,?,?,?,?,'no_reset',?,?,?, '{}','0',?)",
      [$name, $code, (int) ($_POST['price_product'] ?? 0), (int) ($_POST['volume_product'] ?? 0), (int) ($_POST['time_product'] ?? 0), $_POST['namepanel'] ?? '', $_POST['agent_product'] ?? '', $_POST['note_product'] ?? '', $category !== '' ? $category : null, $inboundsVal, $btnStyle !== '' ? $btnStyle : null]
    );
    flash('success', 'محصول «' . $name . '» اضافه شد.');
  } catch (Exception $e) {
    flash('error', 'خطای پایگاه داده: ' . $e->getMessage());
  }
  header('Location: product.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'edit') {
  csrf_check_post();
  $pid = (int) ($_POST['edit_id'] ?? 0);
  $name = function_exists('vira_sanitize_button_emoji_label')
    ? vira_sanitize_button_emoji_label(trim($_POST['name_product'] ?? ''))
    : trim($_POST['name_product'] ?? '');
  if ($pid && $name !== '') {
    $category = trim((string) ($_POST['cetegory_product'] ?? ''));
    if (vira_product_name_taken($pdo, $name, $category, $pid)) {
      $catHint = $category !== '' ? ' در دسته «' . $category . '»' : ' بدون دسته';
      flash('error', 'محصولی با این نام' . $catHint . ' قبلاً ثبت شده.');
      header('Location: product.php');
      exit;
    }
    $inboundsRaw = trim((string) ($_POST['inbounds_product'] ?? ''));
    $panelName = trim((string) ($_POST['namepanel'] ?? ''));
    if ($panelName !== '') {
      $panelRow = db_fetch($pdo, 'SELECT type FROM marzban_panel WHERE name_panel = ?', [$panelName]);
      if ($panelRow && panel_web_is_xui_type((string) ($panelRow['type'] ?? '')) && ($inboundsRaw === '' || $inboundsRaw === '-')) {
        flash('error', 'برای پنل ۳x-ui انتخاب اینباند الزامی است.');
        header('Location: product.php');
        exit;
      }
    }
    $inboundsVal = ($inboundsRaw === '' || $inboundsRaw === '-') ? null : $inboundsRaw;
    $btnStyle = vira_sanitize_btn_style($_POST['btn_style'] ?? '');
    try {
      db_query(
        $pdo,
        "UPDATE product SET name_product=?,price_product=?,Volume_constraint=?,Service_time=?,Location=?,agent=?,note=?,category=?,inbounds=?,btn_style=? WHERE id=?",
        [$name, (int) ($_POST['price_product'] ?? 0), (int) ($_POST['volume_product'] ?? 0), (int) ($_POST['time_product'] ?? 0), $_POST['namepanel'] ?? '', $_POST['agent_product'] ?? '', $_POST['note_product'] ?? '', $category !== '' ? $category : null, $inboundsVal, $btnStyle !== '' ? $btnStyle : null, $pid]
      );
      flash('success', 'محصول ویرایش شد.');
    } catch (Exception $e) {
      flash('error', 'خطا: ' . $e->getMessage());
    }
  }
  header('Location: product.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'clone') {
  csrf_check_post();
  $pid = (int) ($_POST['clone_id'] ?? 0);
  $src = $pid ? db_fetch($pdo, 'SELECT * FROM product WHERE id = ?', [$pid]) : null;
  if (!$src) {
    flash('error', 'محصول برای کپی یافت نشد.');
    header('Location: product.php');
    exit;
  }
  $category = isset($src['category']) && $src['category'] !== '' ? (string) $src['category'] : null;
  $name = vira_product_next_clone_name($pdo, (string) ($src['name_product'] ?? ''), $category);
  $code = bin2hex(random_bytes(2));
  $btnStyle = vira_sanitize_btn_style($src['btn_style'] ?? '');
  try {
    db_query(
      $pdo,
      "INSERT INTO product (name_product,code_product,price_product,Volume_constraint,Service_time,Location,agent,data_limit_reset,note,category,inbounds,hide_panel,one_buy_status,btn_style) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
      [
        $name,
        $code,
        (int) ($src['price_product'] ?? 0),
        (int) ($src['Volume_constraint'] ?? 0),
        (int) ($src['Service_time'] ?? 0),
        $src['Location'] ?? '',
        $src['agent'] ?? 'f',
        $src['data_limit_reset'] ?? 'no_reset',
        $src['note'] ?? '',
        $category,
        $src['inbounds'] ?? null,
        $src['hide_panel'] ?? '{}',
        $src['one_buy_status'] ?? '0',
        $btnStyle !== '' ? $btnStyle : null,
      ]
    );
    flash('success', 'کپی محصول با نام «' . $name . '» ایجاد شد.');
  } catch (Exception $e) {
    flash('error', 'خطا در کپی: ' . $e->getMessage());
  }
  header('Location: product.php');
  exit;
}

if (isset($_GET['delete'])) {
  csrf_check_get();
  db_query($pdo, "DELETE FROM product WHERE id = ?", [(int) $_GET['delete']]);
  flash('success', 'محصول حذف شد.');
  header('Location: product.php');
  exit;
}

$panels = [];
try {
  $panels = db_fetchAll($pdo, "SELECT * FROM marzban_panel");
} catch (Exception $e) {
}
$products = db_fetchAll($pdo, "SELECT * FROM product ORDER BY id");

$emojiLibrary = vira_custom_emoji_list($pdo);

$categories = [];
try {
  $categories = db_fetchAll($pdo, 'SELECT id, remark, btn_style FROM category ORDER BY remark ASC');
} catch (Exception $e) {
  error_log('product.php categories: ' . $e->getMessage());
}

$pageTitle = 'محصولات';
$pageLede = 'فهرست محصولات قابل فروش — نام و دسته از ایموجی Premium پشتیبانی می‌کنند.';
$activeNav = 'product';
$extraCss = ['css/product-inbounds.css', 'css/bot-texts.css'];
$extraJs = ['js/inbound-picker.js', 'js/emoji-insert.js', 'js/categories.js', 'js/product.js', 'js/product-bulk.js'];
include __DIR__ . '/inc/layout_head.php';
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;flex-wrap:wrap;gap:8px" class="fade-up">
  <div style="font-size:.85rem;color:var(--mute)"><?= count($products) ?> محصول · <?= count($categories) ?> دسته</div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <a href="bot-emojis.php" class="btn btn-ghost btn-sm">کتابخانه ایموجی</a>
    <a href="shop-settings.php" class="btn btn-ghost btn-sm"><?= icon('settings', 13) ?> تنظیمات فروشگاه</a>
    <button type="button" class="btn btn-ghost btn-sm" onclick="openModal('catModal')"><?= icon('edit', 13) ?> دسته‌بندی‌ها</button>
    <button class="btn btn-primary" onclick="openModal('addModal')"><?= icon('plus', 14) ?> افزودن محصول</button>
  </div>
</div>

<?php include __DIR__ . '/inc/emoji_picker_bar.php'; ?>

<div class="card fade-up d1">
  <?php if (empty($products)): ?>
    <div class="empty" style="padding:60px 20px">
      <svg class="ill" viewBox="0 0 200 160" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="40" y="30" width="120" height="100" rx="12" fill="var(--surface-3)" />
        <rect x="56" y="50" width="88" height="12" rx="6" fill="var(--border-strong)" />
        <rect x="56" y="72" width="60" height="8" rx="4" fill="var(--border)" />
        <rect x="56" y="90" width="72" height="8" rx="4" fill="var(--border)" />
        <rect x="56" y="108" width="44" height="8" rx="4" fill="var(--border)" />
        <circle cx="155" cy="125" r="22" fill="var(--accent-s)" stroke="var(--accent)" stroke-width="2" />
        <path d="M147 125h16M155 117v16" stroke="var(--accent)" stroke-width="2.5" stroke-linecap="round" />
      </svg>
      <p>هنوز محصولی ثبت نکرده‌اید</p>
      <button class="btn btn-primary" style="margin-top:14px" onclick="openModal('addModal')"><?= icon('plus', 14) ?>
        اضافه
        کردن اولین محصول</button>
    </div>
  <?php else: ?>
    <div class="toolbar">
      <div class="toolbar-title">فهرست محصولات <small>(<?= count($products) ?>)</small></div>
      <div class="search-box" style="min-width:220px">
        <?= icon('search', 14) ?>
        <input type="text" placeholder="جستجو..." data-filter="prodTbl">
        <button type="button" class="search-clear">✕</button>
      </div>
    </div>
    <form method="post" id="productBulkForm" class="product-bulk-bar fade-up d1">
      <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
      <input type="hidden" name="action" value="bulk_price">
      <span class="product-bulk-count"><strong id="bulkSelectedCount">0</strong> محصول انتخاب شده</span>
      <select name="bulk_mode" class="select select-sm">
        <option value="increase">افزایش قیمت</option>
        <option value="decrease">کاهش قیمت</option>
      </select>
      <select name="bulk_type" class="select select-sm">
        <option value="fixed">مبلغ ثابت (تومان)</option>
        <option value="percent">درصدی</option>
      </select>
      <input type="number" name="bulk_amount" class="input input-sm" min="1" placeholder="مقدار" required style="width:100px">
      <button type="submit" class="btn btn-primary btn-sm">اعمال روی انتخاب‌شده‌ها</button>
    </form>
    <div class="tbl-wrap">
      <table id="prodTbl" class="tbl-xl">
        <thead>
          <tr>
            <th style="width:36px"><input type="checkbox" id="prodSelectAll" title="انتخاب همه"></th>
            <th>#</th>
            <th>نام محصول</th>
            <th>قیمت</th>
            <th>حجم</th>
            <th>مدت</th>
            <th>پنل</th>
            <th>دسته</th>
            <th>کد</th>
            <th>inbounds</th>
            <th>عملیات</th>
          </tr>
        </thead>
        <tbody>
          <?php $i = 1;
          foreach ($products as $p): ?>
            <tr>
              <td><input type="checkbox" class="prod-row-cb" name="product_ids[]" value="<?= (int) $p['id'] ?>" form="productBulkForm"></td>
              <td class="cf"><?= $i++ ?></td>
              <td class="cs"><?= htmlspecialchars(vira_panel_product_label((string) ($p['name_product'] ?? ''))) ?></td>
              <td class="cn cs"><?= number_format((int) ($p['price_product'] ?? 0)) ?> <span class="cf">ت</span></td>
              <td class="cn"><?= htmlspecialchars($p['Volume_constraint'] ?? '—') ?> <span class="cf">GB</span></td>
              <td class="cn"><?= htmlspecialchars($p['Service_time'] ?? '—') ?> <span class="cf">روز</span></td>
              <td class="cf"><?= htmlspecialchars(trunc($p['Location'] ?? '—', 16)) ?></td>
              <td><?php if (!empty($p['category'])): ?><span
                    class="tag tag-info"><?= htmlspecialchars(vira_panel_product_label((string) $p['category'])) ?></span><?php else: ?><span
                    class="cf">—</span><?php endif; ?></td>
              <td class="cm" style="font-size:.72rem"><?= htmlspecialchars($p['code_product'] ?? '') ?></td>
              <td class="cm" style="font-size:.68rem;max-width:90px" title="<?= htmlspecialchars((string) ($p['inbounds'] ?? '')) ?>">
                <?= !empty($p['inbounds']) && $p['inbounds'] !== 'null' ? htmlspecialchars(trunc((string) $p['inbounds'], 14)) : '—' ?>
              </td>
              <td>
                <div style="display:flex;gap:5px">
                  <button class="btn btn-ghost btn-sm btn-icon" title="ویرایش"
                    onclick="openEditModal(<?= htmlspecialchars(json_encode($p), ENT_QUOTES) ?>)">
                    <?= icon('edit', 13) ?>
                  </button>
                  <form method="POST" style="display:inline;margin:0">
                    <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
                    <input type="hidden" name="action" value="clone">
                    <input type="hidden" name="clone_id" value="<?= (int) $p['id'] ?>">
                    <button type="submit" class="btn btn-ghost btn-sm btn-icon" title="کپی محصول">
                      <?= icon('copy', 13) ?>
                    </button>
                  </form>
                  <a href="product.php?delete=<?= (int) $p['id'] ?>&_csrf=<?= csrf_token() ?>"
                    class="btn btn-no btn-sm btn-icon" title="حذف"
                    data-confirm="حذف محصول «<?= htmlspecialchars($p['name_product']) ?>»؟">
                    <?= icon('trash', 13) ?>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="modal-veil" id="addModal">
  <div class="modal">
    <div class="modal-head">
      <h3>افزودن محصول جدید</h3>
      <button class="modal-x" onclick="closeModal('addModal')"><?= icon('close', 14) ?></button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="add">
        <?php
        $emojiPickerCompact = true;
        $emojiPickerId = 'addEmojiChips';
        include __DIR__ . '/inc/emoji_picker_bar.php';
        ?>
        <div class="form-grid">
          <div class="field full vira-emoji-wrap">
            <label>نام محصول *</label>
            <input type="text" name="name_product" class="input vira-emoji-field" data-emoji-max="1"
              placeholder="مثلاً: {emoji:star} ۵۰ گیگ یک ماهه" required>
            <p class="field-hint vira-emoji-warn" hidden>حداکثر یک {emoji:slug} — مثل دکمه‌های منوی استارت</p>
          </div>
          <div class="field">
            <label>رنگ دکمه در ربات</label>
            <?php vira_panel_btn_style_select('btn_style', 'add_btn_style'); ?>
          </div>
          <div class="field">
            <label>قیمت (تومان)</label>
            <input type="number" name="price_product" class="input" placeholder="۰" min="0">
          </div>
          <div class="field">
            <label>حجم (GB)</label>
            <input type="number" name="volume_product" class="input" placeholder="۵۰" min="0">
          </div>
          <div class="field">
            <label>مدت (روز)</label>
            <input type="number" name="time_product" class="input" placeholder="۳۰" min="0">
          </div>
          <div class="field">
            <label>دسته‌بندی</label>
            <select name="cetegory_product" id="add_cat" class="select">
              <option value="">— بدون دسته —</option>
              <?php foreach ($categories as $c): ?>
                <option value="<?= htmlspecialchars($c['remark']) ?>"><?= htmlspecialchars($c['remark']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label>پنل</label>
            <select name="namepanel" id="add_panel" class="select">
              <option value="">— انتخاب نشده —</option>
              <?php foreach ($panels as $pl): ?>
                <option value="<?= htmlspecialchars($pl['name_panel'] ?? $pl['id']) ?>">
                  <?= htmlspecialchars($pl['name_panel'] ?? $pl['id']) ?>
                </option><?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label>نمایندگی</label>
            <select name="agent_product" class="select">
              <option value="f">کاربر عادی</option>
              <option value="n">نماینده</option>
              <option value="n2">نماینده پیشرفته</option>
            </select>
          </div>
          <div class="field full">
            <label>اینباند (3x-ui)</label>
            <input type="hidden" name="inbounds_product" id="add_inbounds" value="">
            <div id="add_inbound_picker" class="inbound-picker-box"></div>
          </div>
          <div class="field full">
            <label>توضیحات</label>
            <input type="text" name="note_product" class="input" placeholder="توضیحات اختیاری">
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button type="submit" class="btn btn-primary"><?= icon('plus', 13) ?> ذخیره محصول</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('addModal')">انصراف</button>
      </div>
    </form>
  </div>
</div>

<div class="modal-veil" id="editModal">
  <div class="modal">
    <div class="modal-head">
      <h3>ویرایش محصول</h3>
      <button class="modal-x" onclick="closeModal('editModal')"><?= icon('close', 14) ?></button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="edit_id" id="edit_id">
        <?php
        $emojiPickerCompact = true;
        $emojiPickerId = 'editEmojiChips';
        include __DIR__ . '/inc/emoji_picker_bar.php';
        ?>
        <div class="form-grid">
          <div class="field full vira-emoji-wrap">
            <label>نام محصول *</label>
            <input type="text" name="name_product" id="edit_name" class="input vira-emoji-field" data-emoji-max="1" required>
            <p class="field-hint vira-emoji-warn" hidden>حداکثر یک {emoji:slug}</p>
          </div>
          <div class="field">
            <label>رنگ دکمه در ربات</label>
            <?php vira_panel_btn_style_select('btn_style', 'edit_btn_style'); ?>
          </div>
          <div class="field">
            <label>قیمت (تومان)</label>
            <input type="number" name="price_product" id="edit_price" class="input" min="0">
          </div>
          <div class="field">
            <label>حجم (GB)</label>
            <input type="number" name="volume_product" id="edit_volume" class="input" min="0">
          </div>
          <div class="field">
            <label>مدت (روز)</label>
            <input type="number" name="time_product" id="edit_time" class="input" min="0">
          </div>
          <div class="field">
            <label>دسته‌بندی</label>
            <select name="cetegory_product" id="edit_cat" class="select">
              <option value="">— بدون دسته —</option>
              <?php foreach ($categories as $c): ?>
                <option value="<?= htmlspecialchars($c['remark']) ?>"><?= htmlspecialchars($c['remark']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label>پنل</label>
            <select name="namepanel" id="edit_panel" class="select">
              <option value="">— انتخاب نشده —</option>
              <?php foreach ($panels as $pl): ?>
                <option value="<?= htmlspecialchars($pl['name_panel'] ?? $pl['id']) ?>">
                  <?= htmlspecialchars($pl['name_panel'] ?? $pl['id']) ?>
                </option><?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label>نمایندگی</label>
            <select name="agent_product" id="edit_agent" class="select">
              <option value="f">کاربر عادی</option>
              <option value="n">نماینده</option>
              <option value="n2">نماینده پیشرفته</option>
            </select>
          </div>
          <div class="field full">
            <label>اینباند (3x-ui)</label>
            <input type="hidden" name="inbounds_product" id="edit_inbounds" value="">
            <div id="edit_inbound_picker" class="inbound-picker-box"></div>
          </div>
          <div class="field full">
            <label>توضیحات</label>
            <input type="text" name="note_product" id="edit_note" class="input">
          </div>
        </div>
      </div>
      <div class="modal-foot">
        <button type="submit" class="btn btn-primary"><?= icon('check', 13) ?> ذخیره تغییرات</button>
        <button type="button" class="btn btn-ghost" onclick="closeModal('editModal')">انصراف</button>
      </div>
    </form>
  </div>
</div>

<div class="modal-veil" id="catModal">
  <div class="modal" style="max-width:560px">
    <div class="modal-head">
      <h3>مدیریت دسته‌بندی محصولات</h3>
      <button type="button" class="modal-x" onclick="closeModal('catModal')"><?= icon('close', 14) ?></button>
    </div>
    <div class="modal-body">
      <?php
      $emojiPickerCompact = true;
      $emojiPickerId = 'catEmojiChips';
      include __DIR__ . '/inc/emoji_picker_bar.php';
      ?>
      <form id="catAddForm" style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap;align-items:flex-end">
        <input type="hidden" name="_csrf" value="<?= csrf_token() ?>">
        <div class="vira-emoji-wrap" style="flex:1;min-width:160px">
          <label class="field-hint" style="display:block;margin-bottom:4px">نام دسته</label>
          <input type="text" name="remark" class="input vira-emoji-field" data-emoji-max="1"
            placeholder="نام دسته — {emoji:slug} اختیاری" required style="width:100%">
        </div>
        <div>
          <label class="field-hint" style="display:block;margin-bottom:4px">رنگ دکمه</label>
          <?php vira_panel_btn_style_select('btn_style', 'cat_add_btn_style'); ?>
        </div>
        <button type="submit" class="btn btn-primary btn-sm"><?= icon('plus', 12) ?> افزودن</button>
      </form>
      <div id="catListWrap" class="tbl-wrap">
        <table class="tbl-sm">
          <thead><tr><th>نام</th><th>رنگ</th><th></th></tr></thead>
          <tbody id="catListBody">
            <?php foreach ($categories as $c): ?>
              <tr data-cat-id="<?= (int) $c['id'] ?>">
                <td><input type="text" class="input cat-remark-input vira-emoji-field" data-emoji-max="1" value="<?= htmlspecialchars($c['remark']) ?>" style="font-size:.82rem"></td>
                <td><?php vira_panel_btn_style_select('btn_style', 'cat_style_' . (int) $c['id'], (string) ($c['btn_style'] ?? ''), [], 'cat-style-select'); ?></td>
                <td style="white-space:nowrap">
                  <button type="button" class="btn btn-ghost btn-sm cat-save-btn">ذخیره</button>
                  <button type="button" class="btn btn-no btn-sm cat-del-btn">حذف</button>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <p class="field-hint">نام دسته و محصول در ربات با ایموجی Premium نمایش داده می‌شود. حداکثر یک <code>{emoji:slug}</code> per نام.</p>
    </div>
    <div class="modal-foot">
      <button type="button" class="btn btn-ghost" onclick="closeModal('catModal')">بستن</button>
    </div>
  </div>
</div>

<?php include __DIR__ . '/inc/layout_foot.php'; ?>